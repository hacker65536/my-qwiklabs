# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
PreLaunchSignup::Application.config.secret_token = '73ae57ad182b42ebddcf79287f206359c60aa12eb5357a7d6e379da6155b65f36bf66649f3f023afdc60dadcf59cf3b3b724659bea86f34b4f9ff812b75df25c'
